# TONDE unified website — safe integration preview

## What is included

- All four original HTML documents preserved **unchanged** in `originals/`.
- Working copies under `legacy/` with a small cross-page navigation/iframe-height bridge.
- Shared navigation, footer, responsive shell, and direct HTML route entry points across the site.
- Additional pages for Moment Intelligence, Live Events, Conferences, Sports, Parties, Concerts, and audiences.
- Per-route titles/descriptions, canonical tags, Open Graph basics, sitemap, robots.

## Run locally

From the `tonde_unified_site` folder: `python3 -m http.server 8000` then open `http://localhost:8000/`.

Use any static web server supporting directory index files. The web root must be the extracted `tonde_unified_site` folder.

## Important architectural limitation

This is a **non-destructive integration preview**, not a finished production migration. Existing page bodies are displayed in same-origin iframes to preserve the original CSS and JS without collisions; search engines may not attribute iframe body content to wrapper URLs. Before public deployment, migrate page content into first-class server-rendered/SSG components and remove iframes after visual regression testing.

## Not implemented or verified

- Real authentication, signup/reset flow (legacy area is a prototype).
- Payments/prices/billing.
- Final legally reviewed Privacy Policy and Terms.
- Contact submission backend and live customer support routes.
- Evidence that all marketed advanced capabilities are functional in the deployed product.
- Production security/accessibility/load tests or pixel-by-pixel screenshot regression.
- Hosting configuration or deployment to tonde.io.

## Safety

Original files are unchanged. Additional pages are intentionally separate. Avoid presenting prototype features as already shipped.
